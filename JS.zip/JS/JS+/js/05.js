console.log("05.js start...")
const boxEl = document.querySelector('.box');
boxEl.addEventListener('click', function(){
    console.log("clicked...");
    boxEl.style.backgroundColor='orange'; 
}); 