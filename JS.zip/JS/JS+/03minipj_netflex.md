# NETFLEX CLON CODING
00 Page이동
---
[NETFLEX](https://edu-embadded-curriculum.github.io/02_SCREEN_IMPL_NEXTFLIX.github.io/)


01 index.html
---
![20240115171044](https://github.com/EDU-EMBADDED-CURRICULUM/02_SCREEN_IMPL/assets/84259104/8b010b0a-4cb2-4135-94c7-8236a82c3d7e)


02 login.html
---
![20240115170900](https://github.com/EDU-EMBADDED-CURRICULUM/02_SCREEN_IMPL/assets/84259104/18ef3a48-6649-4c8f-8615-055e85d1907b)

03 main.html
---
![20240115170909](https://github.com/EDU-EMBADDED-CURRICULUM/02_SCREEN_IMPL/assets/84259104/fb467667-934f-457a-b17e-57af8f7bae63)

ISSUE
---
- font-size(main.html)
  - font-size를 rem -> vw 로 잡는 경우 브라우저 크기에 따라 함께 크기 변환  
  - font-size를 rem으로 잡는 경우는 :root 의 font-size에 따라 크기 변환
  - font-size를 px로 잡는 경우 환경변화에 무관하게 고정
- slider(main.html)
  - prev,next 에 대한 이벤트처리(JS에서 진행)
