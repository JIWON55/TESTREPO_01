# 모바일 청첩장
PAGE
---
[청첩장 배포](https://edu-embadded-curriculum.github.io/02_SCREEN_IMPL_WEDDING.github.io/)<br/>
[청첩장 페이지 소스](https://github.com/EDU-EMBADDED-CURRICULUM/02_SCREEN_IMPL_WEDDING.github.io.git)

참고
---
[샘플](https://fromtoday.co.kr/)
