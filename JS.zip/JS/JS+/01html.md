# HTML
Index
---
[참고-]()
- HTML 기본 코드 구조
- h1~h6 , hr, br , p, div, span, entity
- ul>li태그 , ol>li태그
- Emmet 
- Table
- A Tag
- Image Tag
- Video Tag
- Form Tag
- Data-Set Attribute

HTML이란 / HTML 기본 구조코드 
---
[참고](https://webclub.tistory.com/608) |




블럭형태그 vs 인라인태그
---
[참고-01](https://nack1400.tistory.com/entry/HTML-9-Block-%ED%83%9C%EA%B7%B8-Inline-%ED%83%9C%EA%B7%B8-%EB%B9%84%EA%B5%90-%EC%A0%95%EB%A6%AC%EB%B8%94%EB%A1%9Dvs%EC%9D%B8%EB%9D%BC%EC%9D%B8-%ED%83%9C%EA%B7%B8-%EC%A0%95%EB%A6%AC) |
[참고-02](https://sas-study.tistory.com/122)



엔티티
---
[참고-01](https://tcpschool.com/html/html_text_entities) |

EMMET 
---
[참고-01](https://inpa.tistory.com/entry/HTML-%F0%9F%8E%A8-Emmet-%EB%AC%B8%EB%B2%95-%EC%A0%95%EB%A6%AC) |

TABLE
---
[참고-01](https://developer.mozilla.org/ko/docs/Learn/HTML/Tables/Basics) |

A_Tag
---
[참고-91](https://developer.mozilla.org/ko/docs/Web/HTML/Element/a) |

Img_Tag
---
[참고-01](https://developer.mozilla.org/ko/docs/Web/HTML/Element/img) |

Video_Tag
---
[참고-01](https://developer.mozilla.org/ko/docs/Web/HTML/Element/video) |

Form_Tag
---
[참고-01](https://developer.mozilla.org/ko/docs/Web/HTML/Element/form) |

input_tag
---
[참고-01](https://tcpschool.com/html-tags/input) |

정규표현식 정리
---
[참고-01](https://myeonguni.tistory.com/1555) |
[참고-02](https://beagle-dev.tistory.com/114<br/>) |




